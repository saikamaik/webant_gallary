package presentation.presenter

import adapter.RecycleAdapter
import android.annotation.SuppressLint
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import model.PhotoModel
import presentation.view.NewView
import retrofit.APIService

@InjectViewState
class NewPresenter : MvpPresenter<NewView>() {
    lateinit var photos: MutableList<PhotoModel>
    private var page: Int = 1
    private var isLoading = false
    private var isLastPage = false
    private var adapter: RecycleAdapter? = null

    @SuppressLint("CheckResult")
    fun getPhotos() {
        APIService.getNewPhotos(page)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doFinally {
                viewState.hideProgressView()
                isLoading = false
            }
            .subscribe({
                photos.addAll(it.data)
                adapter?.notifyItemInserted(photos.size - 10)
            }, {
                it.printStackTrace()
                viewState.navigateToNoInternetFragment()
            })

    }

    fun loadMoreItems() {
        isLoading = true
        viewState.showProgressView()
        page++
        getPhotos()
    }

    fun isLastPage(): Boolean {
        return isLastPage
    }

    fun isLoading(): Boolean {
        return isLoading
    }

}
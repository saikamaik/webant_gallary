package presentation.presenter

class MainPresenter {

}
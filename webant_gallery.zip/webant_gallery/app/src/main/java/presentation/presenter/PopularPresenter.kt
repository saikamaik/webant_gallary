package presentation.presenter

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import presentation.view.PopularView

@InjectViewState
class PopularPresenter: MvpPresenter<PopularView>() {
}
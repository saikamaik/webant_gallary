package presentation.view

import com.arellomobile.mvp.GenerateViewState
import com.arellomobile.mvp.MvpView

@GenerateViewState
interface PopularView: MvpView {

    fun showRecyclerView()
    fun openimageinfo()
    fun closeimageinfo()
}
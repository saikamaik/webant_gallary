package presentation.view

import com.arellomobile.mvp.GenerateViewState
import com.arellomobile.mvp.MvpView

interface NewView: MvpView {

    fun showRecyclerView()
    fun openImageInfo()
    fun closeImageInfo()
    fun hideProgressView()
    fun showProgressView()
    fun navigateToNoInternetFragment()
}
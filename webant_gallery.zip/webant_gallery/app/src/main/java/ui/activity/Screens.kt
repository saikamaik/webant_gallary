package ui.activity

import com.github.terrakok.cicerone.androidx.FragmentScreen
import ui.fragment.NewFragment

object Screens {
    fun New() = FragmentScreen { NewFragment() }
}
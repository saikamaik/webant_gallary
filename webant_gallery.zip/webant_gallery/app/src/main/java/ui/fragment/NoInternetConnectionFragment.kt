package ui.fragment

import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.webant_gallery.R

class NoInternetConnectionFragment: Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_nointernet, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val image : ImageView = view.findViewById(R.id.image_nointernet)
        image.setImageResource(R.drawable.nointernet)
//        image.setImageDrawable(Drawable.createFromPath("Users/saika/Downloads/android test/assets/nointernet.png"))

        initSwipeRefreshLayout()
    }

    private fun initSwipeRefreshLayout() {
        val mSwipeRefreshLayout = view?.findViewById<SwipeRefreshLayout>(R.id.swipe_container)
        mSwipeRefreshLayout?.setOnRefreshListener {
            if (isNetworkAvailable()) refreshAction()
            mSwipeRefreshLayout.isRefreshing = false
        }
        mSwipeRefreshLayout?.setColorScheme(
            R.color.pink,
            R.color.darker_gray,
            R.color.white,
            R.color.black
        )
    }

    private fun refreshAction() {
        parentFragmentManager
            .beginTransaction()
            .remove(this)
            .commit()
        parentFragmentManager
            .popBackStack()
    }

    private fun isNetworkAvailable(): Boolean {
        val cm =
            context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null
    }

}
package ui.fragment

import adapter.PaginationScrollListener
import adapter.RecycleAdapter
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.arellomobile.mvp.MvpFragment
import com.example.webant_gallery.R
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import model.PhotoModel
import retrofit.APIService

class PopularFragment : MvpFragment() {

    lateinit var adapter: RecycleAdapter
    private var recyclerViewPopular: RecyclerView? = null
    lateinit var photos: MutableList<PhotoModel>
    private var page: Int = 1
    private var isLoading = false
    private var isLastPage = false
    private var myCompositeDisposable = CompositeDisposable()

    @SuppressLint("CheckResult")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_popular, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initRecyclerView()
        initSwipeRefreshLayout()

        getPhotos()
    }

    private fun initRecyclerView() {
        recyclerViewPopular = view?.findViewById(R.id.recyclerViewPopular) as RecyclerView

        recyclerViewPopular?.setHasFixedSize(true)
        val linearLayoutManager = GridLayoutManager(this.context, 2)
        recyclerViewPopular?.layoutManager = linearLayoutManager

        recyclerViewPopular!!.addOnScrollListener(object: PaginationScrollListener(linearLayoutManager) {
            override fun loadMoreItems() {
                isLoading = true
                page++
                getPopularPhotos()
            }

            override fun isLastPage(): Boolean {
                return isLastPage
            }

            override fun isLoading(): Boolean {
                return isLoading
            }
        })
    }

    private fun initSwipeRefreshLayout() {
        val mSwipeRefreshLayout = view?.findViewById<SwipeRefreshLayout>(R.id.swiperefresh)
        mSwipeRefreshLayout?.setOnRefreshListener{
            refreshAction()
            mSwipeRefreshLayout.isRefreshing = false
        }
        mSwipeRefreshLayout?.setColorScheme(
            R.color.pink,
            R.color.darker_gray,
            R.color.white,
            R.color.black
        )
    }

    private fun refreshAction() {
        photos.clear()
        page = 1
        adapter = RecycleAdapter(photos, object : RecycleAdapter.MyViewHolder.Callback {
            override fun onImageClicked(item: PhotoModel) {
                navigateToDetailInformationFragment(item)
            }
        })
        recyclerViewPopular?.adapter = adapter
        adapter.notifyDataSetChanged()
        getPhotos()
    }

    @SuppressLint("CheckResult")
    fun getPopularPhotos() {
        APIService.getPopularPhotos(page)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doFinally {
                isLoading = false
            }
            .subscribe({
                photos.addAll(it.data)
                adapter.notifyItemInserted(photos.size - 10)
            }, {
                it.printStackTrace()
            })
    }

    @SuppressLint("CheckResult")
    fun getPhotos() {
        APIService.getPopularPhotos(page)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doFinally {
                isLoading = false
            }
            .subscribe({
                photos = it.data as MutableList<PhotoModel>
                adapter = RecycleAdapter(photos, object: RecycleAdapter.MyViewHolder.Callback {
                    override fun onImageClicked(item: PhotoModel) {
                        navigateToDetailInformationFragment(item)
                    }
                })
                recyclerViewPopular?.adapter = adapter
            }, {
                it.printStackTrace()
            })
            .let(myCompositeDisposable::add)
    }

    private fun navigateToDetailInformationFragment(photo: PhotoModel) {
        val imageDetailFragment = ImageDetailFragment()
        var args = Bundle()
        args.putString("imageName", photo.name)
        args.putString("imageDescription", photo.description)
        args.putString("imageLink", photo.image.name)
        imageDetailFragment.arguments = args

//        parentFragmentManager
//            .beginTransaction()
//            .replace(R.id.fl_container, imageDetailFragment)
//            .addToBackStack(null)
//            .commit()
    }

}
package ui.fragment

import adapter.RecycleAdapter
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.MvpFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.PresenterType
import com.example.webant_gallery.R
import io.reactivex.disposables.CompositeDisposable
import model.PhotoModel
import presentation.presenter.NewPresenter
import presentation.view.NewView

class NewFragment : MvpAppCompatFragment(), NewView {

    @InjectPresenter(type = PresenterType.WEAK, tag = "newPresenter")
    lateinit var mPresenter: NewPresenter

    private var adapter: RecycleAdapter? = null
    private var recyclerViewNew: RecyclerView? = null
    private var mSwipeRefreshLayout: SwipeRefreshLayout? = null
    private var myCompositeDisposable = CompositeDisposable()
    private lateinit var progressBar: ProgressBar

    @SuppressLint("CheckResult")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return if (this.view != null) this.view
        else inflater.inflate(
            R.layout.fragment_new, container, false
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerView()
        initSwipeRefreshLayout()
        mPresenter.getPhotos()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        recyclerViewNew = null
        recyclerViewNew?.adapter = null
        mSwipeRefreshLayout = null
        adapter = null
    }

    private fun initSwipeRefreshLayout() {
        mSwipeRefreshLayout = view?.findViewById(R.id.swiperefresh)!!
        mSwipeRefreshLayout?.setOnRefreshListener {
//            photos.clear()
//            refreshAction()
            mSwipeRefreshLayout!!.isRefreshing = false
        }
        mSwipeRefreshLayout?.setColorScheme(
            R.color.pink,
            R.color.darker_gray,
            R.color.white,
            R.color.black
        )
    }

    private fun initRecyclerView() {
        recyclerViewNew = view?.findViewById(R.id.recyclerViewNew) as RecyclerView
        progressBar = view?.findViewById(R.id.progressbar) as ProgressBar

        recyclerViewNew?.setHasFixedSize(true)
        val linearLayoutManager = GridLayoutManager(this.context, 2)
        recyclerViewNew?.layoutManager = linearLayoutManager

        adapter = RecycleAdapter(mPresenter.photos, object : RecycleAdapter.MyViewHolder.Callback {
            override fun onImageClicked(item: PhotoModel) {

            }

//        recyclerViewNew!!.addOnScrollListener(object :
//            PaginationScrollListener(linearLayoutManager) {
//
//        })
        })
    }

    private fun refreshAction(photos: MutableList<PhotoModel>) {
        adapter = RecycleAdapter(photos, object : RecycleAdapter.MyViewHolder.Callback {
            override fun onImageClicked(item: PhotoModel) {
                navigateToDetailInformationFragment(item)
            }
        })
        recyclerViewNew?.adapter = adapter
        adapter!!.notifyDataSetChanged()
//        getPhotos()
    }

    override fun showProgressView() {
        progressBar.visibility = View.VISIBLE
    }

    override fun showRecyclerView() {
        TODO("Not yet implemented")
    }

    override fun openImageInfo() {
        TODO("Not yet implemented")
    }

    override fun closeImageInfo() {
        TODO("Not yet implemented")
    }

    override fun hideProgressView() {
        progressBar.visibility = View.INVISIBLE
    }

//    @SuppressLint("CheckResult")
//    fun getPhotos() {
//        context?.let {
//            APIService.getNewPhotos(page, it)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .doFinally {
//                    hideProgressView()
//                    isLoading = false
//                }
//                .subscribe({
//                    photos.addAll(it.data)
//                    adapter?.notifyItemInserted(photos.size - 10)
//                }, {
//                    it.printStackTrace()
////                    navigateToNoInternetFragment()
//                })
//        }
//    }

//    @SuppressLint("CheckResult")
//    fun getPhotos() {
//        context?.let {
//            APIService.getNewPhotos(page, it)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .doFinally {
//                    isLoading = false
//                }
//                .subscribe({
//                    photos = it.data as MutableList<PhotoModel>
//                    adapter = RecycleAdapter(photos, object : RecycleAdapter.MyViewHolder.Callback {
//                        override fun onImageClicked(item: PhotoModel) {
//                            navigateToDetailInformationFragment(item)
//                        }
//                    })
//                    recyclerViewNew?.adapter = adapter
//                }, {
//                    it.printStackTrace()
//                    navigateToNoInternetFragment()
//                })
//                .let(myCompositeDisposable::add)
//        }
//    }


    private fun navigateToDetailInformationFragment(photo: PhotoModel) {
        val imageDetailFragment = ImageDetailFragment()
        var args = Bundle()
        args.putString("imageName", photo.name)
        args.putString("imageDescription", photo.description)
        args.putString("imageLink", photo.image.name)
        imageDetailFragment.arguments = args
    }

    override fun navigateToNoInternetFragment() {
        val noInternetFragment = NoInternetConnectionFragment()
//            parentFragmentManager
//                .beginTransaction()
//                .add(R.id.fl_container, noInternetFragment)
//                .addToBackStack(null)
//                .commit()
    }
}
package model

data class Image(
    val id: Int,
    val name: String
)

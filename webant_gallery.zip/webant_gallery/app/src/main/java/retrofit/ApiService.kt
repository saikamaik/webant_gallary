package retrofit

import io.reactivex.Observable
import model.APIResponse
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory


object APIService {

    fun getNewPhotos(page: Int): Observable<APIResponse> {

//        val client = OkHttpClient.Builder()
//            .addInterceptor(ConnectionManager(context))
//            .build()

        val newPhotos = Retrofit.Builder()
            .baseUrl("http://gallery.dev.webant.ru/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
//            .client(client)
            .build()
            .create(GetData::class.java)
            .getData("http://gallery.dev.webant.ru/api/photos?new=true&limit=10&page=$page")

        return newPhotos
    }

    fun getPopularPhotos(page : Int): Observable<APIResponse> {
        val popularPhotos = Retrofit.Builder()
        .baseUrl("http://gallery.dev.webant.ru/api/")
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .build().create(GetData::class.java)
            .getData("http://gallery.dev.webant.ru/api/photos?popular=true&limit=10&page=$page")

        return popularPhotos
    }
}
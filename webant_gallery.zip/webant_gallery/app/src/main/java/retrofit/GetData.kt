package retrofit

import io.reactivex.Observable
import model.APIResponse
import retrofit2.http.GET
import retrofit2.http.Url

interface GetData {
    @GET()
    fun getData(@Url url: String): Observable<APIResponse>
}